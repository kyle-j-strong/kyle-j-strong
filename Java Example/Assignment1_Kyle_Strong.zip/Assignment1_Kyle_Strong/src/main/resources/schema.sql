CREATE TABLE dog_table (entryNumber INT NOT NULL Primary Key AUTO_INCREMENT, name VARCHAR(30), ownerName VARCHAR(30), breed VARCHAR(50),  gender VARCHAR(40), special VARCHAR(20));

CREATE TABLE breed_table (breed VARCHAR(30));